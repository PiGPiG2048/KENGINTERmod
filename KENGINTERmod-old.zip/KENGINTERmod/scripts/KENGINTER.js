const KENGINTER = extend(Planet, "KENGINTER", Planets.sun, 5, 1, {
    generator: new SerpuloPlanetGenerator(),
    bloom: true,
    radius: 1,
    accessible: true,
    hasAtmosphere: true,
    atmosphereColor: Color.valueOf("80ff00"),
    atmosphereRadIn: 0.02,
    atmosphereRadOut: 0.3,
    localizedName: "[blue]KENGINTERworld"
});
KENGINTER.meshLoader = () => extend(HexMesh, KENGINTER, 2, {});